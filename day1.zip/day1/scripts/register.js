
window.addEventListener('load',function()
{    
   scrollFlag=false;
   selectRef=this.document.querySelector(".accounttype");
   var option=this.document.createElement("option");
   var optionText=this.document.createTextNode("Select Your Account Type");
   option.appendChild(optionText);
   selectRef.appendChild(option); 
   //lambda or arrow function to read array
    data.forEach(element => {
        //read element by key
        this.console.log(element.type);
        option=this.document.createElement("option");
        optionText=this.document.createTextNode(element.type);
        option.appendChild(optionText);
        selectRef.appendChild(option); 

    });


    buttonRef=document.querySelector('button[type=submit]')
    window.addEventListener('change',function()
    {

       checkbox=document.querySelector("#agree:checked");
       if((checkbox)&&(scrollFlag))
        {
         console.log('checked');
         buttonRef.disabled=false;
        }
        else
        {
            scrollFlag=false;
            buttonRef.disabled=true; 
        }

    })



})


function autoTab(field1, len, field2) {
	if (document.getElementById(field1).value.length == len) {
		document.getElementById(field2).focus();
		}
}

function createuser()
{
          
       part1=document.querySelector('#part1');
       part2=document.querySelector('#part2');
       part3=document.querySelector('#part3');
       part4=document.querySelector('#part4');
       this.console.log('Credit Card Number=',part1.value,part2.value,part3.value,part4.value);       
       return false;
   

}

function scrollDetect() {
 if(document.querySelector('.terms').scrollHeight >160)
 {
     scrollFlag=true;
     console.log(scrollFlag);
 }
}
