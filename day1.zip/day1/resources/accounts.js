data=[{
    "type": "Banking/Suvidha"
},
{
    "type": "Credit Card"
},
{
    "type": "NR Rupee Checking Account"
},
{
    "type": "Personal Loan"
},
{
    "type": "Mortgages"
},
{
    "type": "Account Representatives/Signatories"
}
]